# weather_telebot
**Hey**, their I made a program that will control the **telegram bot** by using the python and tell you the current weather of enterd city.

You could fork and clone the repositery and run into your system but you have to use your own api key collected from telegram @botfather and a weather api_key.

First you have to install the libraries first one is "requests" and the second one is "python-telegram-bot"

  `pip install requests`
  
  `pip install python-telegram-bot`
  



The api keys are stored in a python file named as api.py in the following format


  
  >telegram_key = "your_telegram_key_goes_here"
  >
  >weather_key = "your_weather_api_key_goes_here"

know it's ready to run **Thankyou**.
